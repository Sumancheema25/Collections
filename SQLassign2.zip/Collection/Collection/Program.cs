﻿using System;
using System.Collections.Generic;

namespace Collection
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> city = new Dictionary<string, string>();
            city.Add("DLH", "Delhi");
            city.Add("PUN", "Punjab");
            city.Add("LUD", "Ludhiana");
            city.Add("LUC", "Lucknow");
            foreach (KeyValuePair<string, string> kvp in city)
            {
                Console.WriteLine(kvp.Key + " " + kvp.Value);
            }
            Console.ReadLine();
        }
    }
}