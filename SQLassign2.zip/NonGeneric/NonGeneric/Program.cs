﻿using System;
using System.Collections;
using System.Collections.Generic;


namespace Generic
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> mylist = new List<int>(); 
            for (int j = 5; j < 10; j++)
            {
                mylist.Add(j * 3);
            }
  
            foreach (int items in mylist)
            {
                Console.WriteLine(items);

                Console.ReadLine();
            }
        }
    }
}
    
